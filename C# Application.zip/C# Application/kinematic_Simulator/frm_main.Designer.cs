﻿
namespace kinematic_Simulator
{
    partial class frm_main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.hs_TX = new System.Windows.Forms.HScrollBar();
            this.hs_TY = new System.Windows.Forms.HScrollBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_RZ = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_RY = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.hs_RY = new System.Windows.Forms.HScrollBar();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_RX = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_TZ = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_TY = new System.Windows.Forms.TextBox();
            this.txt_TX = new System.Windows.Forms.TextBox();
            this.hs_RZ = new System.Windows.Forms.HScrollBar();
            this.hs_TZ = new System.Windows.Forms.HScrollBar();
            this.hs_RX = new System.Windows.Forms.HScrollBar();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_j7 = new System.Windows.Forms.TextBox();
            this.txt_j6 = new System.Windows.Forms.TextBox();
            this.txt_j5 = new System.Windows.Forms.TextBox();
            this.txt_j4 = new System.Windows.Forms.TextBox();
            this.txt_j3 = new System.Windows.Forms.TextBox();
            this.txt_j2 = new System.Windows.Forms.TextBox();
            this.txt_j1 = new System.Windows.Forms.TextBox();
            this.txt_msg = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_gripper_Close = new System.Windows.Forms.Button();
            this.btn_gripper_Open = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_right_gripper = new System.Windows.Forms.TextBox();
            this.txt_left_gripper = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // hs_TX
            // 
            this.hs_TX.Location = new System.Drawing.Point(54, 36);
            this.hs_TX.Minimum = -100;
            this.hs_TX.Name = "hs_TX";
            this.hs_TX.Size = new System.Drawing.Size(563, 34);
            this.hs_TX.TabIndex = 0;
            this.hs_TX.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hs_TX_Scroll);
            // 
            // hs_TY
            // 
            this.hs_TY.Location = new System.Drawing.Point(54, 70);
            this.hs_TY.Minimum = -100;
            this.hs_TY.Name = "hs_TY";
            this.hs_TY.Size = new System.Drawing.Size(563, 34);
            this.hs_TY.TabIndex = 0;
            this.hs_TY.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hs_TY_Scroll);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txt_RZ);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txt_RY);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.hs_RY);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txt_RX);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_TZ);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_TY);
            this.groupBox1.Controls.Add(this.txt_TX);
            this.groupBox1.Controls.Add(this.hs_RZ);
            this.groupBox1.Controls.Add(this.hs_TZ);
            this.groupBox1.Controls.Add(this.hs_RX);
            this.groupBox1.Controls.Add(this.hs_TY);
            this.groupBox1.Controls.Add(this.hs_TX);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox1.Location = new System.Drawing.Point(25, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(723, 244);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "IK PARAMETER";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(24, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 21);
            this.label13.TabIndex = 2;
            this.label13.Text = "RZ";
            // 
            // txt_RZ
            // 
            this.txt_RZ.Location = new System.Drawing.Point(620, 206);
            this.txt_RZ.Name = "txt_RZ";
            this.txt_RZ.Size = new System.Drawing.Size(81, 29);
            this.txt_RZ.TabIndex = 1;
            this.txt_RZ.Text = "0.0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 174);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 21);
            this.label12.TabIndex = 2;
            this.label12.Text = "RY";
            // 
            // txt_RY
            // 
            this.txt_RY.Location = new System.Drawing.Point(620, 172);
            this.txt_RY.Name = "txt_RY";
            this.txt_RY.Size = new System.Drawing.Size(81, 29);
            this.txt_RY.TabIndex = 1;
            this.txt_RY.Text = "0.0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 139);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 21);
            this.label11.TabIndex = 2;
            this.label11.Text = "RX";
            // 
            // hs_RY
            // 
            this.hs_RY.Location = new System.Drawing.Point(54, 172);
            this.hs_RY.Name = "hs_RY";
            this.hs_RY.Size = new System.Drawing.Size(563, 34);
            this.hs_RY.TabIndex = 0;
            this.hs_RY.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hs_RY_Scroll);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 21);
            this.label10.TabIndex = 2;
            this.label10.Text = "TZ";
            // 
            // txt_RX
            // 
            this.txt_RX.Location = new System.Drawing.Point(620, 136);
            this.txt_RX.Name = "txt_RX";
            this.txt_RX.Size = new System.Drawing.Size(81, 29);
            this.txt_RX.TabIndex = 1;
            this.txt_RX.Text = "0.0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 71);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 21);
            this.label9.TabIndex = 2;
            this.label9.Text = "TY";
            // 
            // txt_TZ
            // 
            this.txt_TZ.Location = new System.Drawing.Point(620, 103);
            this.txt_TZ.Name = "txt_TZ";
            this.txt_TZ.Size = new System.Drawing.Size(81, 29);
            this.txt_TZ.TabIndex = 1;
            this.txt_TZ.Text = "0.28";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 21);
            this.label8.TabIndex = 2;
            this.label8.Text = "TX";
            // 
            // txt_TY
            // 
            this.txt_TY.Location = new System.Drawing.Point(620, 70);
            this.txt_TY.Name = "txt_TY";
            this.txt_TY.Size = new System.Drawing.Size(81, 29);
            this.txt_TY.TabIndex = 1;
            this.txt_TY.Text = "0.03";
            // 
            // txt_TX
            // 
            this.txt_TX.Location = new System.Drawing.Point(620, 36);
            this.txt_TX.Name = "txt_TX";
            this.txt_TX.Size = new System.Drawing.Size(81, 29);
            this.txt_TX.TabIndex = 1;
            this.txt_TX.Text = "0.18";
            // 
            // hs_RZ
            // 
            this.hs_RZ.Location = new System.Drawing.Point(54, 206);
            this.hs_RZ.Name = "hs_RZ";
            this.hs_RZ.Size = new System.Drawing.Size(563, 34);
            this.hs_RZ.TabIndex = 0;
            this.hs_RZ.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hs_RZ_Scroll);
            // 
            // hs_TZ
            // 
            this.hs_TZ.Location = new System.Drawing.Point(54, 104);
            this.hs_TZ.Minimum = -100;
            this.hs_TZ.Name = "hs_TZ";
            this.hs_TZ.Size = new System.Drawing.Size(563, 29);
            this.hs_TZ.TabIndex = 0;
            this.hs_TZ.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hs_TZ_Scroll);
            // 
            // hs_RX
            // 
            this.hs_RX.Location = new System.Drawing.Point(54, 136);
            this.hs_RX.Name = "hs_RX";
            this.hs_RX.Size = new System.Drawing.Size(563, 34);
            this.hs_RX.TabIndex = 0;
            this.hs_RX.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hs_RX_Scroll);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.ForeColor = System.Drawing.Color.Aqua;
            this.label14.Location = new System.Drawing.Point(126, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(505, 45);
            this.label14.TabIndex = 2;
            this.label14.Text = "Inverse Kinematics Demonstration";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IK_Simulator.Properties.Resources.srivas_university;
            this.pictureBox1.Location = new System.Drawing.Point(1007, 23);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(174, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txt_j7);
            this.groupBox2.Controls.Add(this.txt_j6);
            this.groupBox2.Controls.Add(this.txt_j5);
            this.groupBox2.Controls.Add(this.txt_j4);
            this.groupBox2.Controls.Add(this.txt_j3);
            this.groupBox2.Controls.Add(this.txt_j2);
            this.groupBox2.Controls.Add(this.txt_j1);
            this.groupBox2.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox2.Location = new System.Drawing.Point(756, 66);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(136, 242);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "REPLY DATA";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(8, 210);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 21);
            this.label15.TabIndex = 1;
            this.label15.Text = "J7";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(8, 174);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 21);
            this.label7.TabIndex = 1;
            this.label7.Text = "J6";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(8, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 21);
            this.label6.TabIndex = 1;
            this.label6.Text = "J5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(8, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 21);
            this.label5.TabIndex = 1;
            this.label5.Text = "J4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(8, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 21);
            this.label4.TabIndex = 1;
            this.label4.Text = "J3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(8, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 21);
            this.label3.TabIndex = 1;
            this.label3.Text = "J2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(8, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "J1";
            // 
            // txt_j7
            // 
            this.txt_j7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_j7.Location = new System.Drawing.Point(39, 208);
            this.txt_j7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_j7.Name = "txt_j7";
            this.txt_j7.Size = new System.Drawing.Size(84, 29);
            this.txt_j7.TabIndex = 0;
            // 
            // txt_j6
            // 
            this.txt_j6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_j6.Location = new System.Drawing.Point(39, 176);
            this.txt_j6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_j6.Name = "txt_j6";
            this.txt_j6.Size = new System.Drawing.Size(84, 29);
            this.txt_j6.TabIndex = 0;
            // 
            // txt_j5
            // 
            this.txt_j5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_j5.Location = new System.Drawing.Point(39, 146);
            this.txt_j5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_j5.Name = "txt_j5";
            this.txt_j5.Size = new System.Drawing.Size(84, 29);
            this.txt_j5.TabIndex = 0;
            // 
            // txt_j4
            // 
            this.txt_j4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_j4.Location = new System.Drawing.Point(39, 116);
            this.txt_j4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_j4.Name = "txt_j4";
            this.txt_j4.Size = new System.Drawing.Size(84, 29);
            this.txt_j4.TabIndex = 0;
            // 
            // txt_j3
            // 
            this.txt_j3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_j3.Location = new System.Drawing.Point(39, 86);
            this.txt_j3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_j3.Name = "txt_j3";
            this.txt_j3.Size = new System.Drawing.Size(84, 29);
            this.txt_j3.TabIndex = 0;
            // 
            // txt_j2
            // 
            this.txt_j2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_j2.Location = new System.Drawing.Point(39, 56);
            this.txt_j2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_j2.Name = "txt_j2";
            this.txt_j2.Size = new System.Drawing.Size(84, 29);
            this.txt_j2.TabIndex = 0;
            // 
            // txt_j1
            // 
            this.txt_j1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_j1.Location = new System.Drawing.Point(39, 26);
            this.txt_j1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_j1.Name = "txt_j1";
            this.txt_j1.Size = new System.Drawing.Size(84, 29);
            this.txt_j1.TabIndex = 0;
            // 
            // txt_msg
            // 
            this.txt_msg.Location = new System.Drawing.Point(103, 326);
            this.txt_msg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_msg.Name = "txt_msg";
            this.txt_msg.Size = new System.Drawing.Size(987, 23);
            this.txt_msg.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Aqua;
            this.label1.Location = new System.Drawing.Point(33, 328);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "MESSAGE";
            // 
            // btn_gripper_Close
            // 
            this.btn_gripper_Close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_gripper_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_gripper_Close.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_gripper_Close.Location = new System.Drawing.Point(151, 105);
            this.btn_gripper_Close.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_gripper_Close.Name = "btn_gripper_Close";
            this.btn_gripper_Close.Size = new System.Drawing.Size(127, 122);
            this.btn_gripper_Close.TabIndex = 7;
            this.btn_gripper_Close.Text = "CLOSE";
            this.btn_gripper_Close.UseVisualStyleBackColor = false;
            this.btn_gripper_Close.Click += new System.EventHandler(this.btn_gripper_Close_Click);
            // 
            // btn_gripper_Open
            // 
            this.btn_gripper_Open.BackColor = System.Drawing.Color.Green;
            this.btn_gripper_Open.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_gripper_Open.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_gripper_Open.ForeColor = System.Drawing.Color.Yellow;
            this.btn_gripper_Open.Location = new System.Drawing.Point(6, 105);
            this.btn_gripper_Open.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_gripper_Open.Name = "btn_gripper_Open";
            this.btn_gripper_Open.Size = new System.Drawing.Size(139, 122);
            this.btn_gripper_Open.TabIndex = 7;
            this.btn_gripper_Open.Text = "OPEN";
            this.btn_gripper_Open.UseVisualStyleBackColor = false;
            this.btn_gripper_Open.Click += new System.EventHandler(this.btn_gripper_Open_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txt_right_gripper);
            this.groupBox3.Controls.Add(this.txt_left_gripper);
            this.groupBox3.Controls.Add(this.btn_gripper_Open);
            this.groupBox3.Controls.Add(this.btn_gripper_Close);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(897, 66);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(284, 242);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "GRIPPER";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.ForeColor = System.Drawing.Color.Aqua;
            this.label17.Location = new System.Drawing.Point(19, 57);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 20);
            this.label17.TabIndex = 10;
            this.label17.Text = "RIGHT GRIPPER";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.ForeColor = System.Drawing.Color.Aqua;
            this.label16.Location = new System.Drawing.Point(19, 26);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(99, 20);
            this.label16.TabIndex = 10;
            this.label16.Text = "LEFT GRIPPER";
            // 
            // txt_right_gripper
            // 
            this.txt_right_gripper.Location = new System.Drawing.Point(134, 56);
            this.txt_right_gripper.Name = "txt_right_gripper";
            this.txt_right_gripper.Size = new System.Drawing.Size(79, 23);
            this.txt_right_gripper.TabIndex = 9;
            // 
            // txt_left_gripper
            // 
            this.txt_left_gripper.Location = new System.Drawing.Point(134, 27);
            this.txt_left_gripper.Name = "txt_left_gripper";
            this.txt_left_gripper.Size = new System.Drawing.Size(79, 23);
            this.txt_left_gripper.TabIndex = 9;
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1194, 361);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_msg);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "frm_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "kinematic Simulator V1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_main_FormClosing);
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar hs_TX;
        private System.Windows.Forms.HScrollBar hs_TY;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_RZ;
        private System.Windows.Forms.TextBox txt_RY;
        private System.Windows.Forms.TextBox txt_RX;
        private System.Windows.Forms.TextBox txt_TZ;
        private System.Windows.Forms.TextBox txt_TY;
        private System.Windows.Forms.TextBox txt_TX;
        private System.Windows.Forms.HScrollBar hs_RZ;
        private System.Windows.Forms.HScrollBar hs_RY;
        private System.Windows.Forms.HScrollBar hs_TZ;
        private System.Windows.Forms.HScrollBar hs_RX;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_msg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_j7;
        private System.Windows.Forms.TextBox txt_j6;
        private System.Windows.Forms.TextBox txt_j5;
        private System.Windows.Forms.TextBox txt_j4;
        private System.Windows.Forms.TextBox txt_j3;
        private System.Windows.Forms.TextBox txt_j2;
        private System.Windows.Forms.TextBox txt_j1;
        private System.Windows.Forms.Button btn_gripper_Close;
        private System.Windows.Forms.Button btn_gripper_Open;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_right_gripper;
        private System.Windows.Forms.TextBox txt_left_gripper;
    }
}

