﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tools
{
   public static class utilString
    {
        public static String purse_str(String src, String find, int recv_char_count)
        {
            String s1 = "";

            try
            {

                int k = src.IndexOf(find);

                if (find.Length > 3)
                {
                    s1 = src.Substring(k + 4, recv_char_count);
                }
                else
                {
                    s1 = src.Substring(k + 3, recv_char_count);
                }

            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }

            return s1;

        }
        //______________________________________________________________________________________________________________
        public static String purse_str2(String src, String find, int offset, int recv_char_count)
        {
            String s1 = "";

            try
            {

                int k = src.IndexOf(find);

                if (find.Length > 3)
                {
                    s1 = src.Substring(k + offset, recv_char_count);
                }
                else
                {
                    s1 = src.Substring(k + 3, recv_char_count);
                }

            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }

            return s1;

        }
        //__________________________________________________________________________________________________________________
        public static int purse_string_within_bracket(string find_str, string packet, int start_index, string bracket_st, string bracket_end, ref string val)
        {
            int var_start_idx = 0;
            int bracket_st_idx = 0;
            int bracket_end_idx = 0;

            var_start_idx = packet.IndexOf(find_str, start_index);
            if (var_start_idx == -1) return -1;
            bracket_st_idx = packet.IndexOf('[', var_start_idx);
            bracket_end_idx = packet.IndexOf(']', bracket_st_idx);

            val = packet.Substring(bracket_st_idx + 1, bracket_end_idx - bracket_st_idx - 1);

            return bracket_end_idx;
        }
        //_________________________________________________________________________________________________________________
        public static string Get_String_till_termination_char_found(string src, string search_str, string terminal_char)
        {
            string ret_str = "";

            int index = src.IndexOf(search_str);
            if (index == -1) return "";
            else
            {
                index = index + search_str.Length;
                int index_term = src.IndexOf(terminal_char, index);
                ret_str = src.Substring(index, index_term - index);
                return ret_str;
            }
        }
        //_____________________________________________________________________________________________________________________________
        public static string Get_String_from_Exponent_string(string src, string find_str, string terminal_str, int decimal_place)
        {
            string str;
            str = utilString.Get_String_till_termination_char_found(src, find_str, terminal_str);
            decimal d = Decimal.Parse(str, System.Globalization.NumberStyles.Float);
            d = Math.Round(d, decimal_place);
            return  d.ToString();
        }
        //_____________________________________________________________________________________________________________________________
    }//class utilString
}//namespace IK_Simulator
