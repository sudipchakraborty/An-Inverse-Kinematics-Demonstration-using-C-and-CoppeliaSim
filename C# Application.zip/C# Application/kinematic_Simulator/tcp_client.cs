﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.IO;
using System.Threading;
using System.Net.NetworkInformation;

namespace Tools
{
    class tcp_client
    {
        TcpClient tcpclnt;
        public bool connected;
        String IpAddr;
        int port;
        //---------------------------------------
        public tcp_client(String IpAddr, int port)
        {
            //TcpClient tcpclnt = new TcpClient();
            connected = false;
            this.port = port;
            this.IpAddr = IpAddr;
        }
        //--------------------------------------------------------
        public bool present()
        {
            Ping p = new Ping();
            PingReply r;
            r = p.Send(this.IpAddr, 100);

            if (r.Status == IPStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            } 
        }
        //________________________________________________________________________________________
        public bool connect()
        {
            try
            {
                tcpclnt = new TcpClient();
                tcpclnt.SendTimeout = 1000; // in milli second
                tcpclnt.ReceiveTimeout = 1000;// in milli second
                tcpclnt.ReceiveBufferSize = 50000;
                tcpclnt.SendBufferSize = 50000;

                tcpclnt.Connect(IpAddr, port);
                connected = true;
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        //--------------------------------------------------------
        public void close()
        {
            tcpclnt.Close();
        }
        //--------------------------------------------------------
        public bool Data_Received(byte[] src_bfr, byte[] dest_bfr)
        {
            try
            {  
                Stream stm = tcpclnt.GetStream();
                stm.ReadTimeout = 500;

                //   stm.Write(src_bfr, 0, src_bfr.Length);

                for (int i = 0; i < src_bfr.Length; i++)
                {
                   // Thread.Sleep(5);
                    byte b = src_bfr[i];
                    //System.Text.UTF8Encoding enc = new System.Text.UTF8Encoding();
                    //string s = Encoding.UTF8.GetString(src_bfr);
                    stm.WriteByte(b);                 
                }
                int k = stm.Read(dest_bfr, 0, dest_bfr.Length);
                stm.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }  
        }
        //---------------------------------------------------------------------------
    }//class tcp_client
}// namespace Formation_Charger.Tools
