﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
//////////////////////////////////// 
namespace Tools
{
    public static class utilIK
    {
            public static double ToRadians(this double angleIn10thofaDegree)
            {
                // Angle in 10th of a degree
                return (angleIn10thofaDegree * Math.PI) / 180;
            }
        //____________________________________________________________________________________________
        public static double ToDegrees(double radians)
        {
            double degrees = (180 / Math.PI) * radians;
            return (degrees);
        }
        //____________________________________________________________________________________________
        public static double[,] CreateIdentityMatrix(int length)
        {
            double[,] matrix = new double[length, length];
            for (int i = 0, j = 0; i < length; i++, j++)
                matrix[i, j] = 1;
            return matrix;
        }
        //__________________________________________________________________________________________
        public static double[] Get_Identity()
        {
            double[] mat = new double[16];
            mat[0] = 1; mat[4] = 0; mat[8] = 0; mat[12] = 0;
            mat[1] = 0; mat[5] = 1; mat[9] = 0; mat[13] = 0;
            mat[2] = 0; mat[6] = 0; mat[10] = 1; mat[14] = 0;
            mat[3] = 0; mat[7] = 0; mat[11] = 0; mat[15] = 1;

            return mat;
        }
        //_________________________________________________________________________
        public static float[] LoadIdentity (float[] mat)
        {
            mat[0] = 1; mat[4] = 0; mat[8] = 0;   mat[12] = 0;
            mat[1] = 0; mat[5] = 1; mat[9] = 0;   mat[13] = 0;
            mat[2] = 0; mat[6] = 0; mat[10] = 1;  mat[14] = 0;
            mat[3] = 0; mat[7] = 0; mat[11] = 0;  mat[15] = 1;

            return mat;
        }
        //________________________________________________________________________
        public static double[] LoadIdentity(double[] mat)
        {
            mat[0] = 1; mat[4] = 0; mat[8] = 0; mat[12] = 0;
            mat[1] = 0; mat[5] = 1; mat[9] = 0; mat[13] = 0;
            mat[2] = 0; mat[6] = 0; mat[10] = 1; mat[14] = 0;
            mat[3] = 0; mat[7] = 0; mat[11] = 0; mat[15] = 1;

            return mat;
        }
        //_________________________________________________________________________



        
        //________________________________________________________________________
        public static double[] Multiply_With_Identity(double[] a)
        {
            double[] mat = utilIK.Get_Identity();
            return multiply(a, mat);
        }
        //____________________________________________________________________________________________________________
        public static double[] multiply(double[] a, double[] b)
        {
            double[] result = new double[16];
            result[0] = (a[0] * b[0]) + (a[4] * b[1]) + (a[8] * b[2]) + (a[12] * b[3]);
            result[1] = (a[1] * b[0]) + (a[5] * b[1]) + (a[9] * b[2]) + (a[13] * b[3]);
            result[2] = (a[2] * b[0]) + (a[6] * b[1]) + (a[10] * b[2]) + (a[14] * b[3]);
            result[3] = (a[3] * b[0]) + (a[7] * b[1]) + (a[11] * b[2]) + (a[15] * b[3]);

            result[4] = (a[0] * b[4]) + (a[4] * b[5]) + (a[8] * b[6]) + (a[12] * b[7]);
            result[5] = (a[1] * b[4]) + (a[5] * b[5]) + (a[9] * b[6]) + (a[13] * b[7]);
            result[6] = (a[2] * b[4]) + (a[6] * b[5]) + (a[10] * b[6]) + (a[14] * b[7]);
            result[7] = (a[3] * b[4]) + (a[7] * b[5]) + (a[11] * b[6]) + (a[15] * b[7]);

            result[8] = (a[0] * b[8]) + (a[4] * b[9]) + (a[8] * b[10]) + (a[12] * b[11]);
            result[9] = (a[1] * b[8]) + (a[5] * b[9]) + (a[9] * b[10]) + (a[13] * b[11]);
            result[10] = (a[2] * b[8]) + (a[6] * b[9]) + (a[10] * b[10]) + (a[14] * b[11]);
            result[11] = (a[3] * b[8]) + (a[7] * b[9]) + (a[11] * b[10]) + (a[15] * b[11]);

            result[12] = (a[0] * b[12]) + (a[4] * b[13]) + (a[8] * b[14]) + (a[12] * b[15]);
            result[13] = (a[1] * b[12]) + (a[5] * b[13]) + (a[9] * b[14]) + (a[13] * b[15]);
            result[14] = (a[2] * b[12]) + (a[6] * b[13]) + (a[10] * b[14]) + (a[14] * b[15]);
            result[15] = (a[3] * b[12]) + (a[7] * b[13]) + (a[11] * b[14]) + (a[15] * b[15]);
            return result;
        }
        //____________________________________________________________________________________________________________
        public static double[] multiply_3x3(double[] a, double[] b)
        {
            double[] result = new double[9];
            result[0] = (a[0] * b[0]) + (a[3] * b[1]) + (a[6] * b[2]);
            result[1] = (a[1] * b[0]) + (a[4] * b[1]) + (a[7] * b[2]);
            result[2] = (a[2] * b[0]) + (a[5] * b[1]) + (a[8] * b[2]);

            result[3] = (a[0] * b[4]) + (a[3] * b[5]) + (a[6] * b[6]);
            result[4] = (a[1] * b[4]) + (a[4] * b[5]) + (a[7] * b[6]);
            result[5] = (a[2] * b[4]) + (a[5] * b[5]) + (a[8] * b[6]);

            result[6] = (a[0] * b[8]) + (a[3] * b[9]) + (a[6] * b[10]);
            result[7] = (a[1] * b[8]) + (a[4] * b[9]) + (a[7] * b[10]);
            result[8] = (a[2] * b[8]) + (a[5] * b[9]) + (a[8] * b[10]);

            return result;
        }
        //____________________________________________________________________________________________________________
        public static decimal[] Get_Matrix_From_DH_Parameter(double theta,double d,double a,double alpha)
        {
            //double[] result = new double[16];

            //result[0] = Math.Cos(theta); result[0] = Get_Adjusted_Value(result[0], 10);
            //result[1] = Math.Sin(theta); result[1] = Get_Adjusted_Value(result[1], 10);
            //result[2] = 0;
            //result[3] = 0;

            //result[4] = -Math.Sin(theta) * Math.Cos(alpha); result[4] = Get_Adjusted_Value(result[4], 10);
            //result[5] = Math.Cos(theta) * Math.Cos(alpha); result[5] = Get_Adjusted_Value(result[5], 10);
            //result[6] = Math.Sin(alpha); result[6] = Get_Adjusted_Value(result[6], 10);
            //result[7] = 0;

            //result[8] = Math.Sin(theta) * Math.Sin(alpha); result[8] = Get_Adjusted_Value(result[8], 10);
            //result[9] = -Math.Cos(theta) * Math.Sin(alpha); result[9] = Get_Adjusted_Value(result[9], 10);
            //result[10] = Math.Cos(alpha); result[10] = Get_Adjusted_Value(result[10], 10);
            //result[11] = 0;

            //result[12] = a * Math.Cos(theta); result[12] = Get_Adjusted_Value(result[12], 10);
            //result[13] = a * Math.Sin(theta); result[13] = Get_Adjusted_Value(result[13], 10);
            //result[14] = d;
            //result[15] = 1;

            //decimal[] dec = new decimal[16];

            //for (int i = 0; i < 16; i++)
            //{
            //    decimal ds = Decimal.Parse(result[i].ToString(), System.Globalization.NumberStyles.Float);
            //    ds = Math.Round(ds, 4);
            //    dec[i] = ds;
            //}
            //return dec;
            //////////////////////////////////////////////////////////////////////////////////
            double[] mat_th = new double[16];
            double[] mat_d = new double[16];
            double[] mat_a = new double[16];
            double[] mat_alph = new double[16];
            double[] result = new double[16];

            LoadIdentity(mat_th);
            LoadIdentity(mat_d);
            LoadIdentity(mat_a);
            LoadIdentity(mat_alph);
            LoadIdentity(result);

            mat_th = rotate("z", theta, mat_th);
            mat_d = translate("z", d, mat_d);
            mat_a = translate("x", a, mat_a);
            mat_alph = rotate("x", alpha, mat_alph);

            result = multiply(mat_th, mat_d);
            result = multiply(result, mat_a);
            result = multiply(result, mat_alph);

            decimal[] dec = new decimal[16];

            for (int i = 0; i < 16; i++)
            {
                decimal ds = Decimal.Parse(result[i].ToString(), System.Globalization.NumberStyles.Float);
                ds = Math.Round(ds, 4);
                dec[i] = ds;
            }

            return dec;
            ///////////////////////////////////////////////////////////
        }
        //____________________________________________________________________________________________________________
        public static double[] convert_decimal_to_double_matrix(decimal [] mat)
        {
            double[] result_mat = new double[16];
            for(int i=0;i<16;i++)
            {
                result_mat[i] = Convert.ToDouble(mat[i]);
            }
            return result_mat;
        }
        //____________________________________________________________________________________________________________
        public static double[] rotate(string axis,double rad,double[] m)
        {
            if((axis=="x") || (axis == "X"))
            {
                m[5] =Math.Round(Math.Cos(rad),4);
                m[6] = Math.Round(Math.Sin(rad), 4);
                m[9] = Math.Round((-1*Math.Sin(rad)), 4);
                m[10] = Math.Round(Math.Cos(rad), 4);
            }
            if ((axis == "y") || (axis == "Y"))
            {
                m[0] = Math.Cos(rad);
                m[2] = (-1*Math.Sin(rad));
                m[8] = (-1 * Math.Sin(rad));
                m[10] = Math.Cos(rad);
            }
            if ((axis == "z") || (axis == "Z"))
            {
                m[0] =Math.Cos(rad);
                m[1] =Math.Sin(rad);
                m[4] =-1 * Math.Sin(rad);
                m[5] =Math.Cos(rad);
            }
            return m;
        }
        //____________________________________________________________________________________________________________
        public static float[] translate(string dir, float val, float[] mat)
        {
            if (dir == "x")
            {
                mat[12] += val;
            }

            if (dir == "y")
            {
                mat[13] += val;
            }

            if (dir == "z")
            {
                mat[14] += val;
            }

            return mat;
        }
        //____________________________________________________________________________________________________________
        public static double[] translate(string dir, double val, double[] mat)
        {
            if ((dir == "x") || (dir == "X"))
            {
                mat[12] += val;
            }

            if ((dir == "y")|| (dir == "Y"))
            {
                mat[13] += val;
            }

            if ((dir == "z") || (dir == "Z"))
            {
                mat[14] += val;
            }

            return mat;
        }
        //____________________________________________________________________________________________________________
        public static double Get_Adjusted_Value(double val, int pos)
        {
            decimal d = Decimal.Parse(val.ToString(), System.Globalization.NumberStyles.Float);
            d = Math.Round(d, pos);

            double dd = Convert.ToDouble(d);
            return dd;
        }
        //____________________________________________________________________________________________________________
        public static decimal Get_Adjusted_Value(decimal val, int pos)
        {
            decimal d = Decimal.Parse(val.ToString(), System.Globalization.NumberStyles.Float);
            d = Math.Round(d, pos);
            return d;
        }
        //____________________________________________________________________________________________________________
        public static decimal[] Get_Decimal_Matrix_From_Double(double[] mat, int pos)
        {
            decimal[] d_mat = new decimal[16];

            for( int i=0;i<16;i++)
            {
                decimal d = Decimal.Parse(mat[i].ToString(), System.Globalization.NumberStyles.Float);
                d = Math.Round(d, pos);
                d_mat[i] = d;
            }
            return d_mat;
        }
        //____________________________________________________________________________________________________________
        public static void MultiplyMatrix()
        {

            //gl.PushMatrix();

            //            //gl.LoadMatrixf(m);

            //gl.LoadIdentity();

            //GL.glLoadIdentity();
            //GL.glRotatef(theta, 0, 1, 0); //theta
            //GL.glTranslatef(0, d, 0); // d
            //GL.glTranslatef(r, 0, 0); // r
            //GL.glRotatef(alph, 1, 0, 0);// alpha
            //GL.glPopMatrix();




            //float[] m = new float[16];

            //OpenGL gl = new OpenGL();

            //gl.PushMatrix();

            //gl.LoadIdentity();


            //gl.Translate(0, 0, 0);

            //gl.Rotate(0, 0, 0, 0);


            //gl.MultMatrix(m);

            //gl.GetFloat(OpenGL.GL_MODELVIEW_MATRIX,m);

            //gl.PopMatrix();

            ////  Clear the color and depth buffer.
            ////gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

            ////  Load the identity matrix.


            //gl.LoadMatrixf(matrixView);              // Mmv = Mv
            //gl.MultMatrixf(matrixModel);             // Mmv *= Mm


            ////  Rotate around the Y axis.
            //gl.Rotate(rotation, 0.0f, 1.0f, 0.0f);

            ////  Draw a coloured pyramid.
            //gl.Begin(OpenGL.GL_TRIANGLES);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(-1.0f, -1.0f, 1.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(1.0f, -1.0f, 1.0f);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(1.0f, -1.0f, 1.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(1.0f, -1.0f, -1.0f);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(1.0f, -1.0f, -1.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(-1.0f, -1.0f, -1.0f);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(-1.0f, -1.0f, -1.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(-1.0f, -1.0f, 1.0f);
            //gl.End();

            ////  Nudge the rotation.
            //rotation += 3.0f;

            //Matrix mat=new 
            //c = new int[m1, n2];
            //for (int i = 0; i < m1; i++)
            //{
            //    for (int j = 0; j < n2; j++)
            //    {
            //        c[i, j] = 0;
            //        for (int k = 0; k < n1; k++) c[i, j] = c[i, j] + a[i, k] * b[k, j];
            //    }
            //}
        }
        //_____________________________________________________________________________________________
        public static void Fill_DataGrid_With_DH_Parameter(DataGridView dg)
        {
            dg.Rows.Clear();
            dg.Rows.Add(6);

            dg[0, 0].Value = 11; dg[1, 0].Value = 12.02; dg[2, 0].Value = 12.02; dg[3, 0].Value = 12.02;
            dg[0, 1].Value = 12.02; dg[1, 1].Value = 12.02; dg[2, 1].Value = 12.02; dg[3, 1].Value = 12.02;
            dg[0, 2].Value = 12.02; dg[1, 2].Value = 12.02; dg[2, 2].Value = 12.02; dg[3, 2].Value = 12.02;
            dg[0, 3].Value = 12.02; dg[1, 3].Value = 12.02; dg[2, 3].Value = 12.02; dg[3, 3].Value = 12.02;
            dg[0, 4].Value = 12.02; dg[1, 4].Value = 12.02; dg[2, 4].Value = 12.02; dg[3, 4].Value = 12.02;
            dg[0, 5].Value = 12.02; dg[1, 5].Value = 12.02; dg[2, 5].Value = 12.02; dg[3, 5].Value = 12.02;


        }
        //____________________________________________________________________________________________



    }
}








//   mat = get_transform(mat);

//  OpenGL  gl = openGLControl1.OpenGL;


//   gl.LoadMatrixf(mat);

//// Create the appropriate projection matrix.
//   gl.MatrixMode(OpenGL.GL_PROJECTION);

//   gl.PushMatrix();

//   gl.LoadIdentity();
//   gl.Translate(0, 0, .5f);
//   gl.Rotate(30,1, 0, 0);


//double[] val = new double[16];
//frm_matrix mat = new frm_matrix(val);
//mat.Show();


//   float[] modelview=new float[16];
//   gl.GetFloat(OpenGL.GL_MODELVIEW_MATRIX, modelview);


//   gl.PopMatrix();


//   gl.LoadIdentity();

//   gl.LineWidth(5);

//   double[,] mat = new double[4, 4];


//   //  Setup the modelview matrix.
//   gl.MatrixMode(OpenGL.GL_MODELVIEW);
//   gl.LoadIdentity();
//  // gl.MultMatrix()


//  //   Matrix mat1 = new Matrix([4,4]);

//  gl.Begin(OpenGL.GL_LINE_LOOP);
////  gl.DrawText3D("a", 0.2f, 1.0f, "osX: 0");
//  for (int i = 0; i < 200; i++)
//  {
//      float theta = 2.0f * 3.1415926f * (float)i / 200f;//get the current angle

//      float x = 3f * (float)System.Math.Cos(theta);//calculate the x component
//      float y = 3f * (float)System.Math.Sin(theta);//calculate the y component

//      gl.Color(1.0f, 1.0f, 1.0f);
//      gl.Vertex(0f, y + 0.0f, x + 0.0f);//output vertex

//  }

//  gl.End();

// gl.LoadIdentity();

//gl.Color(0.85f, 0.85f, 0.85f, 0.5f);

//gl.Begin(OpenGL.GL_QUADS);
//for (int i = 0; i < 1; i++)
//{
//    this.draw_sphere(gl, 3);
//}
//gl.End();

//gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
//gl.Begin(OpenGL.GL_QUADS);

//gl.LoadIdentity();

//gl.Color(1.0f, 0.0f, 1.0f);
////gl.Vertex(-1.0f, 1.0f, 1.0f);

////gl.Rotate(1, 1, 1);
////gl.Rotate(4,1, 1, 1);

////gl.Translate(1, 1, 1);

////gl.LineWidth(0.5f);

//// openGLControl1.OpenGLDraw()

//gl.End();						// Done Drawing The Q
//gl.Flush();



//gl.Enable(OpenGL.GL_BLEND);
//gl.BlendFunc(OpenGL.GL_SRC_ALPHA, OpenGL.GL_ONE_MINUS_SRC_ALPHA);

////  Draw a coloured parallelepiped.
//gl.Begin(OpenGL.GL_QUADS);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(-2.0f, -0.25f, -1.0f);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(2.0f, -0.25f, -1.0f);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(2.0f, 0.25f, -1.0f);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(-2.0f, 0.25f, -1.0f);






//gl.PushMatrix();

//            //gl.LoadMatrixf(m);

//gl.LoadIdentity();

//GL.glLoadIdentity();
//GL.glRotatef(theta, 0, 1, 0); //theta
//GL.glTranslatef(0, d, 0); // d
//GL.glTranslatef(r, 0, 0); // r
//GL.glRotatef(alph, 1, 0, 0);// alpha
//GL.glPopMatrix();

//Static float[] m = new float[16];
//Add the following codeGL.glGetFloatv(GL.GL_MODELVIEW_MATRIX, m);
//gl.GetFloat(OpenGL.GL_MODELVIEW_MATRIX, m);


